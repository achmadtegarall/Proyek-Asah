// const name = "John";
// const email = "john@gmail.com";
// const age = 25;

// export { name, email, age };

// export default function goodMorning() {
//   console.log("Good morning!");
// }

// export default function sayHi() {
//   console.log("Hai, ini default export dari anotherfile.mjs");
// }

// export function sayGoodBye() {
//   console.log("Bye, ini named export dari anotherfile.mjs");
// }

