//anotherfile.mjs

// import { name, email, age } from "./anothers.mjs";

// console.log(name);
// console.log(email);
// console.log(age);

// import goodMorning from "./anotherfile.mjs";
// import anotherName from "./anotherfile.mjs";

// goodMorning();
// anotherName();

// import sayHi, { sayGoodBye } from './anotherfile.mjs';

// sayHi(); // Hai, ini default export dari anotherfile.mjs
// sayGoodBye(); // Bye, ini named export dari anotherfile.mjs

// import { name, favoriteFood as food } from "./module.mjs";

// console.log(name);
// console.log(food);


//module.mjs


// import { name, favoriteFood } from "./module.mjs";
// console.log(name);
// console.log(favoriteFood);

// import { name, favoriteFood as food, sayHi } from "./module.mjs";

// console.log(name);
// console.log(food);
// sayHi(name);

//keyword *

// import * as user from "./module.mjs";

// console.log(user.name);
// console.log(user.favoriteFood);
// user.sayHi(user.name);
