// export function makeCoffee(callback) {
//   const estimationTime = 5000;

//   const inSecond = Math.ceil(estimationTime / 1000);
//   console.log(`Mohon menunggu. Kopi sedang dibuat dalam ${inSecond} detik`);

//   setTimeout(() => {
//     // Do some tasks to make coffee…

//     callback();
//   }, estimationTime);
// }


export function makeCoffee(name, callback) {
  const estimationTime = 5000;

  const inSecond = Math.ceil(estimationTime / 1000);
  console.log(`Mohon menunggu. Kopi sedang dibuat dalam ${inSecond} detik`);

  setTimeout(() => {


    callback();
  }, estimationTime);
}
