// export const name = "John";
// export const favoriteFood = ["pizza", "pasta", "sushi"];

// export function sayHi(name) {
//   console.log(`Hi, ${name}!`);
// }

// const name = "John";
// const favoriteFood = ["pizza", "pasta", "sushi"];

// function sayHi(name) {
//   console.log(`Hi, ${name}!`);
// }
// export { name, favoriteFood, sayHi };

