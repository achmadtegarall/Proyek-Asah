// import { makeCoffee } from "./coffee.mjs";

// console.log("Saya memesan kopi di kafe.");

// makeCoffee(() => {
//   console.log("Kopi berhasil dibuat.");
// });

// import { makeCoffee } from "./coffee.mjs";

// const order = "Kopi Espresso";

// console.log(`Saya memesan ${order} di kafe.`);

// makeCoffee(order, (makeCoffeeError, makeCoffeeData) => {
//   if (makeCoffeeError) {
  
//     console.error(makeCoffeeError);

//     return;
//   }

//   console.log(`Kopi ${makeCoffeeData} berhasil dibuat.`);
// });


