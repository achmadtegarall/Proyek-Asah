import { API, sampleErrorData, sampleSuccessData } from "./support.mjs";
function processData(data) {
 
  const arrayOfPromises = data.map((item) =>
    API.fetch(item.delay, item.simulateError)
  );

  return Promise.all(arrayOfPromises);
}

processData(sampleErrorData).then(console.log).catch(console.log);
processData(sampleSuccessData).then(console.log).catch(console.log); 
