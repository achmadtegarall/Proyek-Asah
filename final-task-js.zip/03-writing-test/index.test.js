import test from 'node:test';
import assert from 'node:assert';
import { sum } from './index.js';

test('sum should add two positive numbers', () => {
  assert.strictEqual(sum(2, 3), 5);
});

test('sum should add positive and negative number', () => {
  assert.strictEqual(sum(5, -2), 3);
});

test('sum should add two negative numbers', () => {
  assert.strictEqual(sum(-4, -6), -10);
});

test('sum should work with zero', () => {
  assert.strictEqual(sum(0, 7), 7);
});