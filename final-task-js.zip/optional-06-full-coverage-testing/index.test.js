import { test } from 'node:test';
import assert from 'node:assert';
import sum from './index.js';


test('sum of two positive numbers', () => {
  assert.strictEqual(sum(2, 3), 5);
});

test('sum returns 0 if first parameter is not a number', () => {
  assert.strictEqual(sum('2', 3), 0);
});

test('sum returns 0 if second parameter is not a number', () => {
  assert.strictEqual(sum(2, '3'), 0);
});

test('sum returns 0 if both parameters are not numbers', () => {
  assert.strictEqual(sum('2', '3'), 0);
});

test('sum returns 0 if first parameter is negative', () => {
  assert.strictEqual(sum(-2, 3), 0);
});

test('sum returns 0 if second parameter is negative', () => {
  assert.strictEqual(sum(2, -3), 0);
});

test('sum returns 0 if both parameters are negative', () => {
  assert.strictEqual(sum(-2, -3), 0);
});