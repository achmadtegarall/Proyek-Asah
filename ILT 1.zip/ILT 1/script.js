document.addEventListener("DOMContentLoaded", () => {
  const homeScoreElement = document.getElementById("home-score");
  const awayScoreElement = document.getElementById("away-score");

  let homeScore = 0;
  let awayScore = 0;


  function updateScoreDisplay() {
    homeScoreElement.textContent = homeScore;
    awayScoreElement.textContent = awayScore;
  }


  document.querySelectorAll(".score-btn").forEach((button) => {
    button.addEventListener("click", (event) => {
      
      const team = event.currentTarget.dataset.team;
     
      const isPlus = event.currentTarget.classList.contains("plus-btn");


      if (team === "home") {
        if (isPlus) {
          homeScore++;
        } else {
          if (homeScore > 0) {
            homeScore--;
          }
        }
      } else if (team === "away") {
        if (isPlus) {
          awayScore++;
        } else {
          if (awayScore > 0) {
            awayScore--;
          }
        }
      }
   
      updateScoreDisplay();
    });
  });

  // Mengatur skor awal saat halaman pertama kali dimuat
  updateScoreDisplay();
});
