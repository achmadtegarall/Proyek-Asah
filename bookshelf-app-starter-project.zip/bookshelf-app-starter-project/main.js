// Do your work here...
console.log("Hello, world!"); 
//Diatas itu default
const books = [];
const STORAGE_KEY = "BOOKSHELF_APPS";

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("bookForm");
  const searchForm = document.getElementById("searchBook");
  const editForm = document.getElementById("editBookForm");
  const cancelEditBtn = document.getElementById("cancelEdit");

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    addBook();
  });

  searchForm.addEventListener("submit", function (e) {
    e.preventDefault();
    searchBook();
  });

  editForm.addEventListener("submit", function (e) {
    e.preventDefault();
    saveEditedBook();
  });

  cancelEditBtn.addEventListener("click", function () {
    document.getElementById("editSection").style.display = "none";
    document.getElementById("bookForm").parentElement.style.display = "block";
    document.getElementById("searchBook").parentElement.style.display = "block";
    document.getElementById("incompleteBookList").parentElement.style.display =
      "block";
    document.getElementById("completeBookList").parentElement.style.display =
      "block";
    editForm.reset();
  });

  if (isStorageExist()) {
    loadDataFromStorage();
  }
});

function addBook() {
  const title = document.getElementById("bookFormTitle").value;
  const author = document.getElementById("bookFormAuthor").value;
  const year = Number(document.getElementById("bookFormYear").value);
  const isComplete = document.getElementById("bookFormIsComplete").checked;

  const id = +new Date();
  const bookObject = { id, title, author, year, isComplete };

  books.push(bookObject);
  saveData();
  renderBooks();

  document.getElementById("bookForm").reset();
}

function renderBooks(filteredBooks = null) {
  const incompleteShelf = document.getElementById("incompleteBookList");
  const completeShelf = document.getElementById("completeBookList");

  incompleteShelf.innerHTML = "";
  completeShelf.innerHTML = "";

  const displayBooks = filteredBooks || books;

  for (const book of displayBooks) {
    const bookElement = makeBookElement(book);
    if (!book.isComplete) {
      incompleteShelf.append(bookElement);
    } else {
      completeShelf.append(bookElement);
    }
  }
}

function makeBookElement(book) {
  const container = document.createElement("div");
  container.setAttribute("data-bookid", book.id);
  container.setAttribute("data-testid", "bookItem");

  const titleEl = document.createElement("h3");
  titleEl.setAttribute("data-testid", "bookItemTitle");
  titleEl.innerText = book.title;

  const authorEl = document.createElement("p");
  authorEl.setAttribute("data-testid", "bookItemAuthor");
  authorEl.innerText = "Penulis: " + book.author;

  const yearEl = document.createElement("p");
  yearEl.setAttribute("data-testid", "bookItemYear");
  yearEl.innerText = "Tahun: " + book.year;

  const actionDiv = document.createElement("div");

  const toggleBtn = document.createElement("button");
  toggleBtn.setAttribute("data-testid", "bookItemIsCompleteButton");
  toggleBtn.innerText = book.isComplete
    ? "Belum selesai dibaca"
    : "Selesai dibaca";
  toggleBtn.addEventListener("click", function () {
    toggleBookStatus(book.id);
  });

  const deleteBtn = document.createElement("button");
  deleteBtn.setAttribute("data-testid", "bookItemDeleteButton");
  deleteBtn.innerText = "Hapus Buku";
  deleteBtn.addEventListener("click", function () {
    deleteBook(book.id);
  });

  const editBtn = document.createElement("button");
  editBtn.setAttribute("data-testid", "bookItemEditButton");
  editBtn.innerText = "Edit Buku";
  editBtn.addEventListener("click", function () {
    editBook(book.id);
  });

  actionDiv.append(toggleBtn, deleteBtn, editBtn);
  container.append(titleEl, authorEl, yearEl, actionDiv);

  return container;
}

function toggleBookStatus(bookId) {
  const book = books.find((b) => b.id === bookId);
  if (!book) return;

  book.isComplete = !book.isComplete;
  saveData();
  renderBooks();
}

function deleteBook(bookId) {
  const index = books.findIndex((b) => b.id === bookId);
  if (index === -1) return;

  books.splice(index, 1);
  saveData();
  renderBooks();
}

function editBook(bookId) {
  const book = books.find((b) => b.id === bookId);
  if (!book) return;

  document.getElementById("editBookId").value = book.id;
  document.getElementById("editBookTitle").value = book.title;
  document.getElementById("editBookAuthor").value = book.author;
  document.getElementById("editBookYear").value = book.year;
  document.getElementById("editBookIsComplete").checked = book.isComplete;

  document.getElementById("editSection").style.display = "block";

  document.getElementById("bookForm").parentElement.style.display = "none";
  document.getElementById("searchBook").parentElement.style.display = "none";
  document.getElementById("incompleteBookList").parentElement.style.display =
    "none";
  document.getElementById("completeBookList").parentElement.style.display =
    "none";
}

function saveEditedBook() {
  const id = Number(document.getElementById("editBookId").value);
  const title = document.getElementById("editBookTitle").value;
  const author = document.getElementById("editBookAuthor").value;
  const year = Number(document.getElementById("editBookYear").value);
  const isComplete = document.getElementById("editBookIsComplete").checked;

  const book = books.find((b) => b.id === id);
  if (!book) return;

  book.title = title;
  book.author = author;
  book.year = year;
  book.isComplete = isComplete;

  saveData();
  renderBooks();
 
  document.getElementById("editSection").style.display = "none";
  document.getElementById("bookForm").parentElement.style.display = "block";
  document.getElementById("searchBook").parentElement.style.display = "block";
  document.getElementById("incompleteBookList").parentElement.style.display =
    "block";
  document.getElementById("completeBookList").parentElement.style.display =
    "block";

  document.getElementById("editBookForm").reset();
}

function searchBook() {
  const keyword = document
    .getElementById("searchBookTitle")
    .value.toLowerCase();

  const filtered = books.filter((b) => b.title.toLowerCase().includes(keyword));

  if (filtered.length === 0) {
    alert("Maaf, buku yang Anda cari Tidak Ada");
  }

  renderBooks(filtered);
}

function saveData() {
  if (isStorageExist()) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
  }
}

function loadDataFromStorage() {
  const serializedData = localStorage.getItem(STORAGE_KEY);
  if (!serializedData) return;

  const data = JSON.parse(serializedData);
  books.push(...data);
  renderBooks();
}

function isStorageExist() {
  return typeof Storage !== "undefined";
}
