// Achmad Tegar Almannudin - R254D5Y0029 

/*
Goal tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer.
*/