const getData = () => {
  return [
    {
      id: 1,
      name: "Cania Citta",
      tag: "cania",
      imageUrl: "public/images/cania.jpg",
    },
    {
      id: 2,
      name: "Ferry Irwandi",
      tag: "ferry",
      imageUrl: "public/images/ferry.jpg",
    },
    {
      id: 3,
      name: "Rizky Adi Prakoso",
      tag: "rizky",
      imageUrl: "public/images/rizky.jpg",
    },
    {
      id: 3,
      name: "Sabda PS",
      tag: "sabda",
      imageUrl: "public/images/sabda.jpg",
    },
  ];
};

export { getData };
