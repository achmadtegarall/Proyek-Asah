import React from "react";

function SearchBar({ search, setSearch }) {
  return (
    <div className="note-search">
      <input
        type="text"
        placeholder="Cari catatan..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      {search && (
        <span className="clear-btn" onClick={() => setSearch("")}>
          ×
        </span>
      )}
    </div>
  );
}

export default SearchBar;
