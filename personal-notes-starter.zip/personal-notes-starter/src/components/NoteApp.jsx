import React, { useState } from "react";
import { getInitialData } from "../utils";
import NoteList from "./NoteList";
import NoteForm from "./NoteForm";
import SearchBar from "./NoteSearchbar";

function NoteApp() {
  const [notes, setNotes] = useState(getInitialData());
  const [search, setSearch] = useState("");

  const addNote = ({ title, body }) => {
    const newNote = {
      id: +new Date(),
      title,
      body,
      archived: false,
      createdAt: new Date().toISOString(),
    };
    setNotes([...notes, newNote]);
  };

  const deleteNote = (id) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  const toggleArchive = (id) => {
    setNotes(
      notes.map((note) =>
        note.id === id ? { ...note, archived: !note.archived } : note
      )
    );
  };

  const filteredNotes = notes.filter((note) =>
    note.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="note-app">
      <div className="note-app__header">
        <h1>Personal Notes</h1>
        <SearchBar search={search} setSearch={setSearch} />
      </div>
      <div className="note-app__body">
        <NoteForm addNote={addNote} />
        <h2>Catatan Aktif</h2>
        <NoteList
          notes={filteredNotes.filter((n) => !n.archived)}
          onDelete={deleteNote}
          onArchive={toggleArchive}
        />
        <h2>Arsip</h2>
        <NoteList
          notes={filteredNotes.filter((n) => n.archived)}
          onDelete={deleteNote}
          onArchive={toggleArchive}
        />
      </div>
    </div>
  );
}

export default NoteApp;
