import React, { useState } from "react";

function NoteForm({ addNote }) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const charLimit = 50;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (title.trim() && body.trim()) {
      addNote({ title, body });
      setTitle("");
      setBody("");
    }
  };

  return (
    <div className="note-input">
      <h2>Tambah Catatan</h2>
      <form onSubmit={handleSubmit}>
        <p className="note-input__title__char-limit">
          Sisa karakter: {charLimit - title.length}
        </p>
        <input
          type="text"
          placeholder="Judul"
          value={title}
          onChange={(e) => {
            if (e.target.value.length <= charLimit) {
              setTitle(e.target.value);
            }
          }}
          className="note-input__title"
          required
        />
        <textarea
          placeholder="Tuliskan catatanmu di sini..."
          value={body}
          onChange={(e) => setBody(e.target.value)}
          className="note-input__body"
          required
        ></textarea>
        <button type="submit">Tambah</button>
      </form>
    </div>
  );
}

export default NoteForm;
